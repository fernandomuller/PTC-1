
#include "Enquadramento.h"

Enquadramento::Enquadramento(Stream & dev, int bytes_min, int bytes_max) : porta(dev){
	min_bytes = bytes_min;
	max_bytes = bytes_max;
	estado = ocioso;
}

void  Enquadramento::envia(unsigned char * buffer, int bytes){

	unsigned char aux_buffer[max_bytes];
	Serial.print("\nBytes:");Serial.println(bytes);
	
	// Gera CRC e adiciona  ao buffer
	gen_crc( buffer,bytes);
	
	// Prepara o frame
	aux_buffer[0] = 0x7E;// Sentinela início mensagem
	int j = 1;

	for(int i = 0; i<bytes+2; i++){
		if(buffer[i] == 0x7E || buffer[i] == 0x7D){
			aux_buffer[j] = 0x7D;
			j++;
			aux_buffer[j] = buffer[i] xor 0x20;
		}else{
			aux_buffer[j] = buffer[i];
		}
		j++;
	}	
	aux_buffer[j] = 0x7E;// Sentinela final mensagem
	j++;
		
	// Envia o frame	
	int n = 0;
	if( (j>=min_bytes) && (j<=max_bytes) ){	
		n = porta.write(aux_buffer, j);
		Serial.print("Enviou bytes:");Serial.println(n);

	}else{
		Serial.print("\nTamanho da mensagem fora dos limites!!! Mensagem não enviada!");
	}
		
}



int  Enquadramento::recebe(unsigned char* _buffer){
	
	_buffer = buffer[0];
	boolean rx = false, _crc = false;
	n_bytes = 0;
	//----------------------------------------------
	//Entrando em while recepção. BLOQUEANTE!!!  
		
	while(!rx){
		rx = handle( porta.read());	//porta.read_byte()
	}
	Serial.println("\nMensagem Recebida!!!");//Serial.println(n);
	//Saiu while recepção !!!  
	//-------------------------------------------
	_crc = check_crc(buffer, n_bytes);
	if(_crc){
			Serial.println("\nCRC OK!");
			return n_bytes;
	}else{
			Serial.println("\nCRC NOK!!!");
			return 0;
	}		
}

 // aqui se implementa a máquina de estados de recepção
 // retorna true se reconheceu um quadro completo
bool  Enquadramento::handle(unsigned char byte){//Estados {ocioso, rx, esc};  
 //int n_bytes; bytes recebidos pela MEF até o momento 
 //int estado; estado atual da MEF
 
 //printf("%d", estado); printf(":%x ", byte);
 	//char in_buffer[];
 
  switch ( estado )
  {	//-------------------------------------------------------
     case ocioso :
		 	if(byte == 0x7E ){
		 		estado = rx;		 		
			}
			return false;			
     break;
 	//--------------------------------------------------------
     case rx :
			if(byte == 0x7E && n_bytes > 0){
		 		estado = ocioso;
		 		return true;// Fim de quadro !!!
			}else if(byte == 0x7D){
				estado = esc;
				return false;
			}else{
				buffer[n_bytes] = byte;
				n_bytes++;
				return false;
			}
     break;
 	//-------------------------------------------------------------
     case esc :
			if(byte == 0x7E || byte == 0x7D){
		 		estado = ocioso;
		 		//bzero(buffer);
		 		n_bytes = 0;
		 		return false;
			}else{
				estado = rx;
				buffer[n_bytes] = byte xor 0x20;
				n_bytes++;
				return false;
			}
     break;     
 	//-----------------------------------------------------------
     default :
      // printf ("Estado da MEF invalido!\n");
       return false;
  }	
}

bool Enquadramento::check_crc( unsigned char * buffer, int len){		
	uint16_t validacao;
	
	validacao = pppfcs16(PPPINITFCS16,buffer,len);
	if(validacao == PPPGOODFCS16)return true;
	return false;	     
}

void Enquadramento::gen_crc( unsigned char * buffer, int len){
	//uint16_t aux;
	union crc_16
	{
		uint16_t crc_value;
		unsigned char crc_bytes[2];
	};
	crc_16 crc;
         
   crc.crc_value = pppfcs16(PPPINITFCS16,buffer,len);
   crc.crc_value ^= 0xffff;
   
   buffer[len] =  crc.crc_bytes[0] ;//(aux & 0x00ff);     
   buffer[len + 1] = crc.crc_bytes[1];//(aux >> 8);
   
}

uint16_t Enquadramento::pppfcs16(uint16_t fcs, unsigned char * cp, int len){

  // assert(sizeof (uint16_t) == 2);
   //assert(((uint16_t) -1) > 0);

   while (len--) fcs = (fcs >> 8) ^ fcstab[(fcs ^ *cp++) & 0xff];
   return (fcs);

}
